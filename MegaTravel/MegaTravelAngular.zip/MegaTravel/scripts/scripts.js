var reservationApp = angular.module('reservationApp', []);

reservationApp.controller("reservationController", function($scope) {
    $scope.destination = {}
})